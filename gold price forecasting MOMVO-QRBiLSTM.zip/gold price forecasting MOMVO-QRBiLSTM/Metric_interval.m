function [picp, pinaw, AIS] = Metric_interval(alpha,UB,LB,actual)
%(1)计算picp
Num = 0;
for i = 1:length(actual)
    Num = Num +  (actual(i) >= LB(i) && actual(i) <= UB(i));  % 越大越好
end
picp = Num / length(actual)*100;  

%(2)计算pinaw
pinaw = 1/range(actual) * sum((UB - LB)./ actual);     % 越小，区间越窄

%(3)计算AIS
epsilon = UB - LB;
for i = 1:length(actual)
    if actual(i) < LB(i)
        S1(i) = -2*alpha*epsilon(i) - 4*(LB(i) - actual(i));
    elseif actual(i) > UB(i)
        S1(i) = -2*alpha*epsilon(i) - 4*(actual(i) - UB(i));
    elseif actual(i)>=LB(i) & actual(i)<=UB(i)
        S1(i) = -2*alpha*epsilon(i);
    end
end
AIS = mean(S1);    % S值即AIS越大越好
  