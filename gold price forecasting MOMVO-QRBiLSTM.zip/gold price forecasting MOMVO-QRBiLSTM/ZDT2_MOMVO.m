function o= ZDT2(x,y1,actual,tau)
o = [0,0];
Yt=x(1)*y1;%修正系数乘预测值

if tau>0.5
picp = sum(Yt>actual)/length(actual)*100; %picp上界 
pinaw = 1/range(actual) * sum( (Yt-actual )./ actual); %pinaw上界
else
picp = sum(Yt<actual)/length(actual)*100 ;%picp下界
pinaw = 1/range(actual) * sum( (actual -Yt )./ actual); %pinaw下界
end

%目标函数 objective function
o(1) = min((1-tau)-picp,pinaw*(1+exp(-0.05*(picp-1+tau))));
 o(2) = mean(abs(Yt-actual(1:end))./actual(1:end))*100;
%o(2)= mean(max(tau*(actual-Yt),(1-tau)*(Yt-actual)));

% o(1)=mean(abs(Yt-xtrain_output)./xtrain_output)
% o(2)=var(abs(Yt-xtrain_output)./xtrain_output)
% o(1)=mean((Yt-actual).^2);%
% o(2)=std(Yt);
% o(1)=mean((Yt-actual(1:288)).^2);
% o(1)=mean(abs(Yt-actual(1:end))./actual(1:end))*100;
% o(2)=std(Yt-actual(1:end));

 

 

