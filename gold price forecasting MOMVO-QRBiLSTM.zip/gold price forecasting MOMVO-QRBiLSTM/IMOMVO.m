function [Best_universe,optimized_train,optimized_test]=IMOMVO(dim,y1,y2,actual,tau)
ObjectiveFunction=@ZDT2_MOMVO;
% Welded beam design optimization
dim=1;
lb=0;
ub=2;
obj_no=2;
if size(ub,2)==1
    ub=ones(1,dim)*ub;
    lb=ones(1,dim)*lb;
end

%%%%%
% Initial parameters of the MOMOVA algorithm
Max_time=200;
N=100;
ArchiveMaxSize=100;
 
Archive_X=zeros(ArchiveMaxSize,dim);
Archive_F=ones(ArchiveMaxSize,obj_no)*inf;
Archive_member_no=0;

%Initialize the positions of universes
Universes=(initialization(N,dim,ub,lb))';
Best_universe=zeros(dim,1); 
Best_universe_Inflation_rate=inf*ones(1,obj_no); %change this to -inf for maximization problems 

%Minimum and maximum of Wormhole Existence Probability (min and max in
% Eq.(3.3) in the paper
WEP_Max=1;
WEP_Min=0.2;
%Iteration(time) counter
Time=1;

%Main loop
for time =1:Max_time

    WEP=WEP_Min+Time*((WEP_Max-WEP_Min)/Max_time);
       %Travelling Distance Rate (Formula): Eq. (3.4) in the original MVO paper
    TDR=1-((Time)^(1/6)/(Max_time)^(1/6));
   for i=1:N 

       Flag4ub=Universes(:,i)>ub';
       Flag4lb=Universes(:,i)<lb';
       Universes(:,i)=(Universes(:,i).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
       %Calculate the inflation rate (fitness) of universes
      [Inflation_rates(i,:)]=ObjectiveFunction(Universes(:,i)',y1(1:end),actual(1:end),tau);

        if dominates(Inflation_rates(i,:),Best_universe_Inflation_rate)
            Best_universe_Inflation_rate=Inflation_rates(i,:);
            Best_universe=Universes(:,i);
        end
   end
   [Archive_X, Archive_F, Archive_member_no]=UpdateArchive1(Archive_X, Archive_F, Universes, Inflation_rates, Archive_member_no);
   if Archive_member_no>ArchiveMaxSize
      Archive_mem_ranks=RankingProcess(Archive_F, ArchiveMaxSize, obj_no);
      [Archive_X, Archive_F, Archive_member_no]=HandleFullArchive(Archive_X, Archive_F, Archive_member_no, Archive_mem_ranks, ArchiveMaxSize);
   else
        Archive_mem_ranks=RankingProcess(Archive_F, ArchiveMaxSize, obj_no);
   end
    Archive_mem_ranks=RankingProcess(Archive_F, ArchiveMaxSize, obj_no);
    index=RouletteWheelSelection(1./Archive_mem_ranks);
   if index==-1
      index=1;
   end
   Best_universe_Inflation_rate=Archive_F(index,:);
   Best_universe=Archive_X(index,:)'; 

  
    
    %Inflation rates (I) (fitness values)
    %Inflation_rates=zeros(1,size(Universes,1));
    [sorted_Inflation_rates,sorted_indexes]=sort(Inflation_rates);
    for newindex=1:N
        Sorted_universes(:,newindex)=Universes(:,sorted_indexes(newindex));
    end
    
    %Normaized inflation rates (NI in Eq. (3.1) in the original MVO paper)
    normalized_sorted_Inflation_rates=normr(sorted_Inflation_rates);
   
    Universes(1,:)= Sorted_universes(1,:);
    
    % to improve coverage
  
   
    %Update the Position of universes
    for i=2:size(Universes,1)%Starting from 2 since the firt one is the elite
        Back_hole_index=i;
        for j=1:size(Universes,2)
            r1=rand();
            if r1<normalized_sorted_Inflation_rates(i)
                White_hole_index=RouletteWheelSelection(-sorted_Inflation_rates);% for maximization problem -sorted_Inflation_rates should be written as sorted_Inflation_rates
                if White_hole_index==-1
                    White_hole_index=1;
                end
                %Eq. (3.1) in the paper
                Universes(Back_hole_index,j)=Sorted_universes(White_hole_index,j);
            end
            
            if (size(lb',1)==1)
                %Eq. (3.2) in the original MVO paper if the boundaries are all the same
                r2=rand();
                if r2<WEP
                    r3=rand();
                    if r3<0.5
                        Universes(i,j)=Best_universe(1,j)+TDR*((ub-lb)*rand+lb);
                    end
                    if r3>0.5
                        Universes(i,j)=Best_universe(1,j)-TDR*((ub-lb)*rand+lb);
                    end
                end
            end
            
            if (size(lb',1)~=1)
                %Eq. (3.2) in the original MVO paper if the upper and lower bounds are
                %different for each variables
                r2=rand();
                if r2<WEP
                    r3=rand();
                    if r3<0.5
                        Universes(i,j)=Best_universe(1,j)+TDR*((ub(j)-lb(j))*rand+lb(j));
                    end
                    if r3>0.5
                        Universes(i,j)=Best_universe(1,j)-TDR*((ub(j)-lb(j))*rand+lb(j));
                    end
                end
            end
            
        end
    end   
 %display(['At the iteration ', num2str(Time), ' there are ', num2str(Archive_member_no), ' non-dominated solutions in the archive']);
end

Best_universe=Best_universe;
optimized_train=Best_universe*y1;  
optimized_test=Best_universe*y2;
o=actual(1:end);


%% 评价指标
%pinaw = 1/range(actual) * sum( (yuce-actual )./ actual); %pinaw上界
%picp = sum(yuce>actual)/length(actual)*100 %picp上界 
% picp = sum(yuce<actual)/length(actual)*100 %picp下界
% pinaw = 1/range(actual) * sum( (actual -yuce)./ actual); %pinaw下界
% error=yuce-actual(1:end);
% MAPE=mean(abs(error)./actual(1:end))*100;
% MAE=mean(abs(error));
% RMSE=sqrt(mse(yuce-actual(1:end)));
% SDE=std(error);
% sum(Best_universe);
end
