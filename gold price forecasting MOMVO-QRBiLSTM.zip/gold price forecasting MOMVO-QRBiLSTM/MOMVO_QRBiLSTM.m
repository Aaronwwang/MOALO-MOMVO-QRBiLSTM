clear;
clc;
%%  Import data
%gold data
n=0.7;%Percentage of training set
load gold_lag_s_sen_US_G.mat
train=gold_price(1:880*n,:);
test=gold_price(880*n+1:879,:);
validation=gold_price(880*n-184:880*n,:);

P_train = train(:,2:end)';  %Columns 1-20 of the train are stored into P_train P is variable, T is y
T_train = train(:,1)';   
P_test = test(:,2:end)';
T_test = test(:,1)';
P_validation=validation(:,2:end)';
T_validation=validation(:,1)';
f=size(P_train, 1);                  % Input feature dimensions
outdim = 1;                           % The last column is the output
%%  Divide the training set and test set
M = size(P_train, 2);
N = size(P_test, 2);

%%  data normalization
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

[p_validation, ps_P_validation] = mapminmax(P_validation, 0, 1);
[t_validation, ps_T_validation] = mapminmax(T_validation, 0, 1);

[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);

% interval prediction
tau1 = [0.05,0.95];
for i = 1:2
[LSTM_validation(i,:)]=QRbiLSTM(p_train, t_train,ps_T_validation,p_validation,t_validation,tau1(i));
end
alpha = 1-(tau1(2)-tau1(1));
[picp_val, pinaw_val, AIS_val] = Metric_interval(alpha,LSTM_validation(2,:),LSTM_validation(1,:),T_validation)

validation_LB=LSTM_validation(1,:);
validation_UB=LSTM_validation(2,:);
actual_validation=T_validation;

%optimization
load gold_bilstm.mat
PRE_LB=gold_biLSTM(1,:);
PRE_UB=gold_biLSTM(2,:);

dim=1;%dimansion of inputs
[Best_universe_LB,optimized_validation_LB,optimized_biLSTM_LB]=...
      IMOMVO(dim,validation_LB,PRE_LB,actual_validation,tau1(1));%优化下界
quantileloss_LB_opt = QR(T_test, optimized_biLSTM_LB, tau1(1))

[Best_universe_UB,optimized_validation_UB,optimized_biLSTM_UB]=...
      IMOMVO(dim,validation_UB,PRE_UB,actual_validation,tau1(2));%优化上界
quantileloss_UB_opt = QR(T_test, optimized_biLSTM_UB, tau1(2))
%Calculation of optimized evaluation indicators
actual = T_test;
UB = optimized_biLSTM_UB;
LB = optimized_biLSTM_LB;
[picp_opt, pinaw_opt, AIS_opt] = Metric_interval(alpha,UB,LB,actual)

MOMVO_biLSTM_05=[LB;UB];

%save('MOMVO_biLSTM_05','MOMVO_biLSTM_05');
