clc
clear
load PRE_LSTM_mult25.mat
load T_test.mat
tau = 0.975
dim=1;
y1= PRE_LSTM_mult25(2,:); 
actual= T_test;
[train,multU25,MAPE,MAE,RMSE,SDE]=IMOMVO(dim,y1,actual,tau);
pinaw = 1/range(actual) * sum( (multU25-actual )./ actual) %pinaw上界
picp = sum(multU25>actual)/length(actual)*100 %picp上界 

%picp = sum(uniL25<actual)/length(actual)*100   %picp下界
%pinaw = 1/range(actual) * sum( (actual -uniL25 )./ actual)   %pinaw下界


disp(['SDE:' num2str(SDE) ...
     'RMSE:' num2str(RMSE)...
     'MAE:' num2str(MAE)...
     'MAPE:' num2str(MAPE) '%'])