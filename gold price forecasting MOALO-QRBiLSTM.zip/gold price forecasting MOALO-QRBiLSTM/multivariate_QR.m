clear;clc;
%%  导入数据
%%铜价
% load common_train.mat
% P_train = common_train(:,1:4)';  %commom_train的第1-20行存放到P_train中 P变量，T铜
% T_train = common_train(:,end)';   %取最后一列  
% 
% load common_test.mat
% P_test = common_test(:,1:4)';
% T_test = common_test(:,end)';

%天然气
% n=0.7;%训练集占比
% load gas_price_3.mat
% train=gas_price(1:880*n,:);
% test=gas_price(880*n+1:879,:);

%金价
n=0.7;%训练集占比
load gold_lag_s_sen_US_G.mat
train=gold_price(1:880*n,:);
test=gold_price(880*n+1:879,:);

P_train = train(:,2:end)';  %xtrain的第1-20列存放到P_train中 P变量，T铜
T_train = train(:,1)';   
P_test = test(:,2:end)';
T_test = test(:,1)';
f_=size(P_train, 1);                  % 输入特征维度
outdim = 1;                           % 最后一列为输出
%%  划分训练集和测试集
M = size(P_train, 2);
N = size(P_test, 2);
%%  数据归一化
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);

%% 区间预测
tau1 = [0.05,0.95];
for i = 1:2
[gold_biLSTM(i,:)]=QRbiLSTM(p_train, t_train,ps_output,p_test,T_test,tau1(i));
% PICP(n) = sum(PRE_QR>T_test)/length(T_test)*100;%PICP半区间指标
quantileloss = QR(T_test, gold_biLSTM(i,:), tau1(i))
end
%画图
% hold on
% plot(gold_LSTM','r-')
% plot(T_test,'b')
% hold off
%评价指标
alpha = 1-(tau1(2)-tau1(1));
UB = gold_biLSTM(2,:);
LB = gold_biLSTM(1,:);
actual = T_test;
[picp, pinaw, AIS] = Metric_interval(alpha,UB,LB,actual)

%%核密度估计
% %% 预测0.0001到0.9999. 间隔0.005
% tau1 = 0.001:0.005:0.999;
% for i = 1:length(tau1)
%     PRE_LSTM(i,:)=QRLSTM(p_train, t_train,ps_output,p_test,T_test,tau1(i));
% end

% %% KDE
% load result.mat
% %设置核函数分别为Gaussian，Uniform，Triangle和Epanechnikov
% %调用ksdensity函数进行核密度检验
% %[f_ks1,xi1]=ksdensity(score,'kernel','normal');
% %[f_ks2,xi2]=ksdensity(score,'kernel','box');
% %[f_ks3,xi3]=ksdensity(score,'kernel','triangle');
% %[f_ks4,xi4]=ksdensity(score,'kernel','epanechnikov');
% % 绘制几个时刻上的概率密度
% for i = 1:4
%     data = PRE_LSTM(:,i);
%     [f_ks1,xi1]=ksdensity(data,'kernel','epanechnikov');
%     subplot(2,2,i)
%     plot(xi1,f_ks1,'b','linewidth',1);
%     xlabel('电力负荷')
%     ylabel('条件概率密度')
%     ylim=get(gca,'Ylim'); 
%     hold on
%     plot([output_test(i,:),output_test(i,:)],ylim,'r--','linewidth',1); % 绘制x=1的直线
% end


