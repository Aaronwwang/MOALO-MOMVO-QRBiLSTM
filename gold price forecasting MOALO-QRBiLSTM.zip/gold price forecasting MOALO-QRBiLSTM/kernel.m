clc;
clear;
%%  导入数据
load common_train.mat
P_train = common_train(:,1:4)';  %P变量，T铜
T_train = common_train(:,end)';  %取最后一列
load common_test.mat
P_test = common_test(:,1:4)';
T_test = common_test(:,end)';
f_=size(P_train, 1);             %输入特征维度
outdim = 1;                      %最后一列为输出
%%  划分训练集和测试集
M = size(P_train, 2);
N = size(P_test, 2);
%%  数据归一化
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);
[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);

% 预测0.0001到0.9999. 间隔0.005
tau1 = 0.001:0.005:0.999;
for i = 1:length(tau1)
    tau=tau1(i)
    RNN(i,:)=QRNN(p_train, t_train, ps_output, ...
        p_test, T_test, tau1(i));
end