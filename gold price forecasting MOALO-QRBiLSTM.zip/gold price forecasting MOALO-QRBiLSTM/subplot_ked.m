subplot(2,3,1)
    data1 = S_LSTM(:,210);
    data2 = S_GRU(:,210);
    data3 = S_biLSTM1(:,210);
    data4 = S_RNN(:,210);
    data5 = S_SA(:,210);
    data6 = S_QL(:,210);
    data7 = S_IMOTSO1(:,210);

    [f_ks1,xi1]=ksdensity(data1,'kernel','epanechnikov');
    [f_ks2,xi2]=ksdensity(data2,'kernel','epanechnikov');
    [f_ks3,xi3]=ksdensity(data3,'kernel','epanechnikov');
    [f_ks4,xi4]=ksdensity(data4,'kernel','epanechnikov');
    [f_ks5,xi5]=ksdensity(data5,'kernel','epanechnikov');
    [f_ks6,xi6]=ksdensity(data6,'kernel','epanechnikov');
    [f_ks7,xi7]=ksdensity(data7,'kernel','epanechnikov');
    % [f_ks1,xi1]=ksdensity(data,'kernel','epanechnikov');
    plot(xi1,f_ks1,'b--','linewidth',1);
    hold on
    plot(xi2,f_ks2,'c','linewidth',1);
    hold on
    plot(xi3,f_ks3,'g','linewidth',1);
    hold on
    plot(xi4,f_ks4,'m--','linewidth',1);
    hold on
    plot(xi5,f_ks5,'k--','linewidth',1);
    hold on
    plot(xi6,f_ks6,'y','linewidth',1);
    hold on
    plot(xi7,f_ks6,'r','linewidth',1);
    hold on
    xlabel('Electricity Price')
    ylabel(['Probability Density'])
    title('The 210th moment')
    ylim=get(gca,'Ylim'); 
    hold on
    plot([A(210,:),A(210,:)],ylim,'r-.','linewidth',1); % 绘制x=1的直线)
    legend('QRLSTM','QRGRU','QR-biLSTM','QRNN','SA','QLWA','IMOTSO','Actual')

    subplot(2,3,2)
    data1 = S_LSTM(:,262);
    data2 = S_GRU(:,262);
    data3 = S_biLSTM1(:,262);
    data4 = S_RNN(:,262);
    data5 = S_SA(:,262);
    data6 = S_QL(:,262);
    data7 = S_IMOTSO1(:,262);

    [f_ks1,xi1]=ksdensity(data1,'kernel','epanechnikov');
    [f_ks2,xi2]=ksdensity(data2,'kernel','epanechnikov');
    [f_ks3,xi3]=ksdensity(data3,'kernel','epanechnikov');
    [f_ks4,xi4]=ksdensity(data4,'kernel','epanechnikov');
    [f_ks5,xi5]=ksdensity(data5,'kernel','epanechnikov');
    [f_ks6,xi6]=ksdensity(data6,'kernel','epanechnikov');
    [f_ks7,xi7]=ksdensity(data7,'kernel','epanechnikov');
    % [f_ks1,xi1]=ksdensity(data,'kernel','epanechnikov');
    plot(xi1,f_ks1,'b--','linewidth',1);
    hold on
    plot(xi2,f_ks2,'c','linewidth',1);
    hold on
    plot(xi3,f_ks3,'g','linewidth',1);
    hold on
    plot(xi4,f_ks4,'m--','linewidth',1);
    hold on
    plot(xi5,f_ks5,'k--','linewidth',1);
    hold on
    plot(xi6,f_ks6,'y','linewidth',1);
    hold on
    plot(xi7,f_ks6,'r','linewidth',1);
    hold on
    xlabel('Electricity Price')
    ylabel(['Probability Density'])
    title('The 262th moment')
    ylim=get(gca,'Ylim'); 
    hold on
    plot([A(262,:),A(262,:)],ylim,'r-.','linewidth',1); % 绘制x=1的直线)
    legend('QRLSTM','QRGRU','QR-biLSTM','QRNN','SA','QLWA','IMOTSO','Actual')


    subplot(2,3,3)
    data1 = S_LSTM(:,309);
    data2 = S_GRU(:,309);
    data3 = S_biLSTM1(:,309);
    data4 = S_RNN(:,309);
    data5 = S_SA(:,309);
    data6 = S_QL(:,309);
    data7 = S_IMOTSO1(:,309);

    [f_ks1,xi1]=ksdensity(data1,'kernel','epanechnikov');
    [f_ks2,xi2]=ksdensity(data2,'kernel','epanechnikov');
    [f_ks3,xi3]=ksdensity(data3,'kernel','epanechnikov');
    [f_ks4,xi4]=ksdensity(data4,'kernel','epanechnikov');
    [f_ks5,xi5]=ksdensity(data5,'kernel','epanechnikov');
    [f_ks6,xi6]=ksdensity(data6,'kernel','epanechnikov');
    [f_ks7,xi7]=ksdensity(data7,'kernel','epanechnikov');
    % [f_ks1,xi1]=ksdensity(data,'kernel','epanechnikov');
    plot(xi1,f_ks1,'b--','linewidth',1);
    hold on
    plot(xi2,f_ks2,'c','linewidth',1);
    hold on
    plot(xi3,f_ks3,'g','linewidth',1);
    hold on
    plot(xi4,f_ks4,'m--','linewidth',1);
    hold on
    plot(xi5,f_ks5,'k--','linewidth',1);
    hold on
    plot(xi6,f_ks6,'y','linewidth',1);
    hold on
    plot(xi7,f_ks6,'r','linewidth',1);
    hold on
    xlabel('Electricity Price')
    ylabel(['Probability Density'])
    title('The 309th moment')
    ylim=get(gca,'Ylim'); 
    hold on
    plot([A(309,:),A(309,:)],ylim,'r-.','linewidth',1); % 绘制x=1的直线)
    legend('QRLSTM','QRGRU','QR-biLSTM','QRNN','SA','QLWA','IMOTSO','Actual')

    subplot(2,3,4)
    data1 = S_LSTM(:,360);
    data2 = S_GRU(:,360);
    data3 = S_biLSTM1(:,360);
    data4 = S_RNN(:,360);
    data5 = S_SA(:,360);
    data6 = S_QL(:,360);
    data7 = S_IMOTSO1(:,360);

    [f_ks1,xi1]=ksdensity(data1,'kernel','epanechnikov');
    [f_ks2,xi2]=ksdensity(data2,'kernel','epanechnikov');
    [f_ks3,xi3]=ksdensity(data3,'kernel','epanechnikov');
    [f_ks4,xi4]=ksdensity(data4,'kernel','epanechnikov');
    [f_ks5,xi5]=ksdensity(data5,'kernel','epanechnikov');
    [f_ks6,xi6]=ksdensity(data6,'kernel','epanechnikov');
    [f_ks7,xi7]=ksdensity(data7,'kernel','epanechnikov');
    % [f_ks1,xi1]=ksdensity(data,'kernel','epanechnikov');
    plot(xi1,f_ks1,'b--','linewidth',1);
    hold on
    plot(xi2,f_ks2,'c','linewidth',1);
    hold on
    plot(xi3,f_ks3,'g','linewidth',1);
    hold on
    plot(xi4,f_ks4,'m--','linewidth',1);
    hold on
    plot(xi5,f_ks5,'k--','linewidth',1);
    hold on
    plot(xi6,f_ks6,'y','linewidth',1);
    hold on
    plot(xi7,f_ks6,'r','linewidth',1);
    hold on
    xlabel('Electricity Price')
    ylabel(['Probability Density'])
    title('The 360th moment')
    ylim=get(gca,'Ylim'); 
    hold on
    plot([A(360,:),A(360,:)],ylim,'r-.','linewidth',1); % 绘制x=1的直线)
    legend('QRLSTM','QRGRU','QR-biLSTM','QRNN','SA','QLWA','IMOTSO','Actual')

    subplot(2,3,5)
    data1 = S_LSTM(:,408);
    data2 = S_GRU(:,408);
    data3 = S_biLSTM1(:,408);
    data4 = S_RNN(:,408);
    data5 = S_SA(:,408);
    data6 = S_QL(:,408);
    data7 = S_IMOTSO1(:,408);

    [f_ks1,xi1]=ksdensity(data1,'kernel','epanechnikov');
    [f_ks2,xi2]=ksdensity(data2,'kernel','epanechnikov');
    [f_ks3,xi3]=ksdensity(data3,'kernel','epanechnikov');
    [f_ks4,xi4]=ksdensity(data4,'kernel','epanechnikov');
    [f_ks5,xi5]=ksdensity(data5,'kernel','epanechnikov');
    [f_ks6,xi6]=ksdensity(data6,'kernel','epanechnikov');
    [f_ks7,xi7]=ksdensity(data7,'kernel','epanechnikov');
    % [f_ks1,xi1]=ksdensity(data,'kernel','epanechnikov');
    plot(xi1,f_ks1,'b--','linewidth',1);
    hold on
    plot(xi2,f_ks2,'c','linewidth',1);
    hold on
    plot(xi3,f_ks3,'g','linewidth',1);
    hold on
    plot(xi4,f_ks4,'m--','linewidth',1);
    hold on
    plot(xi5,f_ks5,'k--','linewidth',1);
    hold on
    plot(xi6,f_ks6,'y','linewidth',1);
    hold on
    plot(xi7,f_ks6,'r','linewidth',1);
    hold on
    xlabel('Electricity Price')
    ylabel(['Probability Density'])
    title('The 408th moment')
    ylim=get(gca,'Ylim'); 
    hold on
    plot([A(408,:),A(408,:)],ylim,'r-.','linewidth',1); % 绘制x=1的直线)
    legend('QRLSTM','QRGRU','QR-biLSTM','QRNN','SA','QLWA','IMOTSO','Actual')

    subplot(2,3,6)
    data1 = S_LSTM(:,455);
    data2 = S_GRU(:,455);
    data3 = S_biLSTM1(:,455);
    data4 = S_RNN(:,455);
    data5 = S_SA(:,455);
    data6 = S_QL(:,455);
    data7 = S_IMOTSO1(:,455);
    [f_ks1,xi1]=ksdensity(data1,'kernel','epanechnikov');
    [f_ks2,xi2]=ksdensity(data2,'kernel','epanechnikov');
    [f_ks3,xi3]=ksdensity(data3,'kernel','epanechnikov');
    [f_ks4,xi4]=ksdensity(data4,'kernel','epanechnikov');
    [f_ks5,xi5]=ksdensity(data5,'kernel','epanechnikov');
    [f_ks6,xi6]=ksdensity(data6,'kernel','epanechnikov');
    [f_ks7,xi7]=ksdensity(data7,'kernel','epanechnikov');
    % [f_ks1,xi1]=ksdensity(data,'kernel','epanechnikov');
    plot(xi1,f_ks1,'b--','linewidth',1);
    hold on
    plot(xi2,f_ks2,'c','linewidth',1);
    hold on
    plot(xi3,f_ks3,'g','linewidth',1);
    hold on
    plot(xi4,f_ks4,'m--','linewidth',1);
    hold on
    plot(xi5,f_ks5,'k--','linewidth',1);
    hold on
    plot(xi6,f_ks6,'y','linewidth',1);
    hold on
    plot(xi7,f_ks6,'r','linewidth',1);
    hold on
    xlabel('Electricity Price')
    ylabel(['Probability Density'])
    title('The 455th moment')
    ylim=get(gca,'Ylim'); 
    hold on
    plot([A(455,:),A(455,:)],ylim,'r-.','linewidth',1); % 绘制x=1的直线)
    legend('QRLSTM','QRGRU','QR-biLSTM','QRNN','SA','QLWA','IMOTSO','Actual')
